import java.io.IOException;
import java.util.*;
import org.apache.kafka.clients.consumer.*;


import java.util.Properties;
import java.util.regex.Pattern;


public class CustomKafkaConsumer {
    //private static final String ZKHOST = "210.125.146.116";
    private static final String BROKERHOST = "210.125.146.181";
    private static final String BROKERPORT = "9092";
    private static final String TOPIC1 = "testa";

    public static void main(String[] args) throws IOException {

        //consumer properties
        Properties consumerProps = new Properties();
        consumerProps.setProperty("bootstrap.servers", BROKERHOST + ":" + BROKERPORT);
        consumerProps.setProperty("group.id", "group1");
        consumerProps.setProperty("client.id", "consumer1");
        //consumerProps.setProperty("session.timeout.ms","30000");
        //consumerProps.setProperty("enable.auto.commit","true");
        consumerProps.setProperty("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
        consumerProps.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        consumerProps.put("auto.offset.reset", "latest");  // to make sure the consumer starts from the beginning of the topic
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(consumerProps);
        consumer.subscribe(Pattern.compile(TOPIC1));
        //infinite poll loop
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(600);
            for (ConsumerRecord<String, String> record : records) {
                try {
                    System.out.println("===>: "+record.value().toString());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
}
